export default {
  appName: "PhoneInfoga",
  appDescription:
    "Advanced information gathering & OSINT tool for phone numbers",
  apiUrl: "/api",
};
